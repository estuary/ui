/* @ts-self-types="./flow_web.d.ts" */
import * as wasm from "./flow_web_bg.wasm";
import { __wbg_set_wasm } from "./flow_web_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    evaluate_field_selection, get_resource_config_pointers, get_trigger_config_schema, resolve_built_collections, restore_trigger_hmac_excluded_fields, skim_collection_projections, strip_trigger_hmac_excluded_fields, update_materialization_resource_spec
} from "./flow_web_bg.js";
