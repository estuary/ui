/* tslint:disable */
/* eslint-disable */

/**
 * Evaluates field selection for a materialization binding.
 *
 * This function runs the improved field selection logic and returns detailed
 * information about why each field was selected or rejected, along with the
 * final field selection configuration.
 *
 * # Input Structure
 *
 * The input should be a JSON object with these fields:
 * - `collection`: Object containing:
 *   - `name`: The collection name (e.g., "acmeCo/users")
 *   - `model`: The collection definition
 * - `binding`: Object containing:
 *   - `live`: Optional existing materialization binding spec
 *   - `model`: The materialization binding configuration from the user
 *   - `validated`: Validated constraints from the connector
 *
 * # Returns
 *
 * Returns a `FieldSelectionResult` containing:
 * - `outcomes`: Per-field selection/rejection reasons
 * - `selection`: Final field selection with keys/values/document
 * - `hasConflicts`: Whether there are unresolved conflicts
 *
 * # Errors
 *
 * Returns JavaScript errors for invalid input or evaluation failures.
 */
export function evaluate_field_selection(input: any): any;

export function get_resource_config_pointers(input: any): any;

export function get_trigger_config_schema(): any;

/**
 * Resolves the collections of a built capture or materialization.
 *
 * A built spec names the collection of each binding either inline, or by
 * `collectionIndex` into its `linkedCollections` table. This function
 * converts the spec to the indirect form, and returns its table alongside
 * the explicit table index of each active binding.
 *
 * # Input Structure
 *
 * The input should be a JSON object with these fields:
 * - `specType`: Either "capture" or "materialization"
 * - `builtSpec`: The built spec, as stored in `live_specs.built_spec` or `draft_specs.built_spec`
 *
 * # Returns
 *
 * Returns an object containing:
 * - `collections`: Array of distinct collection specs, ordered by name
 * - `bindings`: For each active binding in order, the index of its collection
 *   in `collections`, or null if the binding doesn't resolve to a collection
 *
 * # Errors
 *
 * Returns JavaScript errors for invalid input or processing failures.
 */
export function resolve_built_collections(input: any): any;

/**
 * Restore HMAC-excluded fields to an encrypted triggers JSON string. Pass the
 * `originals` token returned by `strip_trigger_hmac_excluded_fields` and the
 * encrypted JSON string returned by the config-encryption service. Returns the
 * final triggers JSON string with non-secret fields restored.
 */
export function restore_trigger_hmac_excluded_fields(encrypted_json: string, originals: any): any;

/**
 * Skims projections from a collection definition.
 *
 * This function processes a collection's schema, key, and projection definitions
 * to derive the actual projections that would be available for materialization.
 * It validates the collection configuration and returns both the projections
 * and any validation errors.
 *
 * # Input Structure
 *
 * The input should be a JSON object with these fields:
 * - `collection`: The collection name (e.g., "acmeCo/users")
 * - `model`: The complete collection definition including schema, key, and projections
 *
 * # Returns
 *
 * Returns a `CollectionProjectionsResult` containing:
 * - `projections`: Array of derived projection objects
 * - `errors`: Array of validation error messages
 *
 * # Errors
 *
 * Returns JavaScript errors for invalid input or processing failures.
 */
export function skim_collection_projections(input: any): any;

/**
 * Strip HMAC-excluded fields from trigger configs before passing to the
 * config-encryption service. Returns `{stripped, originals}` where `stripped`
 * is the JSON string to send for encryption and `originals` is an opaque token
 * to pass back to `restore_trigger_hmac_excluded_fields` afterward.
 */
export function strip_trigger_hmac_excluded_fields(triggers_json: string): any;

export function update_materialization_resource_spec(input: any): any;
