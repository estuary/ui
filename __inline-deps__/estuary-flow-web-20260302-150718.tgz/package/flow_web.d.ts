/* tslint:disable */
/* eslint-disable */
/**
 * Evaluates field selection for a materialization binding.
 *
 * This function runs the improved field selection logic and returns detailed
 * information about why each field was selected or rejected, along with the
 * final field selection configuration.
 *
 * # Input Structure
 *
 * The input should be a JSON object with these fields:
 * - `collection`: Object containing:
 *   - `name`: The collection name (e.g., "acmeCo/users")
 *   - `model`: The collection definition
 * - `binding`: Object containing:
 *   - `live`: Optional existing materialization binding spec
 *   - `model`: The materialization binding configuration from the user
 *   - `validated`: Validated constraints from the connector
 *
 * # Returns
 *
 * Returns a `FieldSelectionResult` containing:
 * - `outcomes`: Per-field selection/rejection reasons
 * - `selection`: Final field selection with keys/values/document
 * - `hasConflicts`: Whether there are unresolved conflicts
 *
 * # Errors
 *
 * Returns JavaScript errors for invalid input or evaluation failures.
 */
export function evaluate_field_selection(input: any): any;
/**
 * Skims projections from a collection definition.
 *
 * This function processes a collection's schema, key, and projection definitions
 * to derive the actual projections that would be available for materialization.
 * It validates the collection configuration and returns both the projections
 * and any validation errors.
 *
 * # Input Structure
 *
 * The input should be a JSON object with these fields:
 * - `collection`: The collection name (e.g., "acmeCo/users")
 * - `model`: The complete collection definition including schema, key, and projections
 *
 * # Returns
 *
 * Returns a `CollectionProjectionsResult` containing:
 * - `projections`: Array of derived projection objects
 * - `errors`: Array of validation error messages
 *
 * # Errors
 *
 * Returns JavaScript errors for invalid input or processing failures.
 */
export function skim_collection_projections(input: any): any;
export function get_resource_config_pointers(input: any): any;
export function update_materialization_resource_spec(input: any): any;
