import * as wasm from "./flow_web_bg.wasm";
export * from "./flow_web_bg.js";
import { __wbg_set_wasm } from "./flow_web_bg.js";
__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
